<?php 
/**
 * Admin Help page
 * 
 * @author Pavel Kulbakin <p.kulbakin@gmail.com>
 */
class PMXI_Admin_Help extends PMXI_Controller_Admin {
	
	public function index() {
		$this->render();
	}
}