<?php

function pmai_wp_loaded() {			
	
	
}